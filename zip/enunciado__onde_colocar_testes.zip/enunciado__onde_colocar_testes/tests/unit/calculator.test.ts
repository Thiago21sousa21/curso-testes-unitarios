describe("calculator tests", () => {
  it("should work", async () => {
    expect(true).toBe(true);
  });
})