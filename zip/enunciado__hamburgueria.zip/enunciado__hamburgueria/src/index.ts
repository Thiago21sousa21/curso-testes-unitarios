import app from "./app";

app.listen(5000, () => {
  console.log("Server is up and running");
});