describe("Infractions Service Tests", () => {
  it("should get infractions from user", async () => {
    // TODO
    expect(true).toBe(true);
  });

  it("should throw an error when driver license does not exists", () => {
    // TODO
    expect(true).toBe(true);
  })
});